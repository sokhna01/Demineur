import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Frame extends JFrame implements ActionListener, MouseListener  {
    //static int FrameRate = 12;

    int ranges = 10;
    int colonnes = 10;
    int numMines = 10;
    GridLayout layout = new GridLayout(ranges, colonnes);
    boolean[] mines = new boolean[ranges * colonnes];
    boolean[] clickable = new boolean[ranges * colonnes];
    boolean perdu = false;
    boolean gagn = false;
    int[] numbers = new int[ranges * colonnes];
    JButton[] buttons = new JButton[ranges * colonnes];
    boolean[] click = new boolean[ranges * colonnes];
    JMenuItem newGameButton = new JMenuItem("Recommencer la partie");
    JMenuItem difficult = new JMenuItem("options");
    JLabel mineLabel = new JLabel("mines: " + numMines + " marqu: 0");
    JPanel p = new JPanel();
    boolean flag = false;


    
 
    public Frame(String title) {
        
        setTitle(title);
        setSize(500,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);
        setLocationRelativeTo(null);
        setVisible(true);
        //setContentPane(p);
        
        p.setLayout(layout);
        setupI();
        for (int i = 0; i < (ranges * colonnes); i++) {
            p.add(buttons[i]);
        }
        JMenuBar mb = new JMenuBar();
        JMenu m = new JMenu("Jeu");
        newGameButton.addActionListener(this);
        m.add(newGameButton);
        difficult.addActionListener(this);
        m.add(difficult);
        mb.add(m);
        this.setJMenuBar(mb);
        this.add(p);
        this.add(mineLabel, BorderLayout.SOUTH);
        this.pack();
        this.setVisible(true);
    }
 
    public void fillMines() {
        int needed = numMines;
        while (needed > 0) {
            int x = (int) Math.floor(Math.random() * ranges);
            int y = (int) Math.floor(Math.random() * colonnes);
            if (!mines[(ranges * y) + x]) {
                mines[(ranges * y) + x] = true;
                needed--;
            }
        }
    }
 
    public void fillNumbers() {
        for (int x = 0; x < ranges; x++) {
            for (int y = 0; y < colonnes; y++) {
                int cur = (ranges * y) + x;
                if (mines[cur]) {
                    numbers[cur] = 0;
                    continue;
                }
                int temp = 0;
                boolean l = (x - 1) >= 0;
                boolean r = (x + 1) < ranges;
                boolean u = (y - 1) >= 0;
                boolean d = (y + 1) < colonnes;
                int left = (ranges * (y)) + (x - 1);
                int right = (ranges * (y)) + (x + 1);
                int up = (ranges * (y - 1)) + (x);
                int upleft = (ranges * (y - 1)) + (x - 1);
                int upright = (ranges * (y - 1)) + (x + 1);
                int down = (ranges * (y + 1)) + (x);
                int downleft = (ranges * (y + 1)) + (x - 1);
                int downright = (ranges * (y + 1)) + (x + 1);
                if (u) {
                    if (mines[up]) {
                        temp++;
                    }
                    if (l) {
                        if (mines[upleft]) {
                            temp++;
                        }
                    }
                    if (r) {
                        if (mines[upright]) {
                            temp++;
                        }
                    }
                }
                if (d) {
                    if (mines[down]) {
                        temp++;
                    }
                    if (l) {
                        if (mines[downleft]) {
                            temp++;
                        }
                    }
                    if (r) {
                        if (mines[downright]) {
                            temp++;
                        }
                    }
                }
                if (l) {
                    if (mines[left]) {
                        temp++;
                    }
                }
                if (r) {
                    if (mines[right]) {
                        temp++;
                    }
                }
                numbers[cur] = temp;
            }
        }
    }
 
    public void setupI() {
        for (int x = 0; x < ranges; x++) {
            for (int y = 0; y < colonnes; y++) {
                mines[(ranges * y) + x] = false;
                click[(ranges * y) + x] = false;
                clickable[(ranges * y) + x] = true;
                buttons[(ranges * y) + x] = new JButton( /*"" + ( x * y )*/);
                buttons[(ranges * y) + x].setPreferredSize(new Dimension(
                        45, 45));
                buttons[(ranges * y) + x].addActionListener(this);
                buttons[(ranges * y) + x].addMouseListener(this);
            }
        }
        fillMines();
        fillNumbers();
    }

    public void setupI2() {
        this.remove(p);
        p = new JPanel();
        layout = new GridLayout(ranges, colonnes);
        p.setLayout(layout);
        buttons = new JButton[ranges * colonnes];
        mines = new boolean[ranges * colonnes];
        click = new boolean[ranges * colonnes];
        clickable = new boolean[ranges * colonnes];
        numbers = new int[ranges * colonnes];
        setupI();
        for (int i = 0; i < (ranges * colonnes); i++) {
            p.add(buttons[i]);
        }
        this.add(p);
        this.pack();
        fillMines();
        fillNumbers();
    }
 
    public void setup() {
        for (int x = 0; x < ranges; x++) {
            for (int y = 0; y < colonnes; y++) {
                mines[(ranges * y) + x] = false;
                click[(ranges * y) + x] = false;
                clickable[(ranges * y) + x] = true;
                buttons[(ranges * y) + x].setEnabled(true);
                buttons[(ranges * y) + x].setText("");
            }
        }
        fillMines();
        fillNumbers();
        perdu = false;
        mineLabel.setText("mines: " + numMines + " marked: 0");
    }
 
   
 
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == difficult) {
            ranges = Integer.parseInt((String) JOptionPane.showInputDialog(
                    this, "Rows", "Rows", JOptionPane.PLAIN_MESSAGE, null,
                    null, 10));
            colonnes = Integer.parseInt((String) JOptionPane.showInputDialog(
                    this, "Columns", "Columns", JOptionPane.PLAIN_MESSAGE,
                    null, null, 10));
            numMines = Integer.parseInt((String) JOptionPane.showInputDialog(this, "Mines", "Mines",
                    JOptionPane.PLAIN_MESSAGE, null, null, 10));
            setupI2();
        }
        if (!gagn) {
            for (int x = 0; x < ranges; x++) {
                for (int y = 0; y < colonnes; y++) {
                    if (e.getSource() == buttons[(ranges * y) + x]
                            && !gagn && clickable[(ranges * y) + x]) {
                        doCheck(x, y);
                        break;
                    }
                }
            }
        }
        if (e.getSource() == newGameButton) {
            setup();
            gagn = false;
            return;
 
        }
        checkWin();
    }
 
    public void mouseEntered(MouseEvent e) {
    }
 
    public void mouseExited(MouseEvent e) {
    }
 
    public void mousePressed(MouseEvent e) {
        if (e.getButton() == 3) {
            int n = 0;
            for (int x = 0; x < ranges; x++) {
                for (int y = 0; y < colonnes; y++) {
                    if (e.getSource() == buttons[(ranges * y) + x]) {
                        clickable[(ranges * y) + x] = !clickable[(ranges * y)
                                + x];
                    }
                    if (!click[(ranges * y) + x]) {
                        if (!clickable[(ranges * y) + x]) {
                            //buttons[(ranges * y) + x].setText("X");
                            buttons[(ranges * y) + x].setIcon(new ImageIcon(getClass().getResource("images/drapeau.png")));
                            n++;
                        } else {
                            buttons[(ranges * y) + x].setText("");
                        }
                        mineLabel.setText("mines: " + numMines + " marked: "
                                + n);
                    }
                }
            }
        }






    }
 
    public void mouseReleased(MouseEvent e) {
    }
 
    public void mouseClicked(MouseEvent e) {
    }
 
    public void doCheck(int x, int y) {
        int cur = (ranges * y) + x;
        boolean l = (x - 1) >= 0;
        boolean r = (x + 1) < ranges;
        boolean u = (y - 1) >= 0;
        boolean d = (y + 1) < colonnes;
        int left = (ranges * (y)) + (x - 1);
        int right = (ranges * (y)) + (x + 1);
        int up = (ranges * (y - 1)) + (x);
        int upleft = (ranges * (y - 1)) + (x - 1);
        int upright = (ranges * (y - 1)) + (x + 1);
        int down = (ranges * (y + 1)) + (x);
        int downleft = (ranges * (y + 1)) + (x - 1);
        int downright = (ranges * (y + 1)) + (x + 1);
 
        click[cur] = true;
        buttons[cur].setEnabled(false);
        if (numbers[cur] == 0 && !mines[cur] && !perdu && !gagn) {
            if (u && !gagn) {
                if (!click[up] && !mines[up]) {
                    click[up] = true;
                    buttons[up].doClick();
                }
                if (l && !gagn) {
                    if (!click[upleft] && numbers[upleft] != 0
                            && !mines[upleft]) {
                        click[upleft] = true;
                        buttons[upleft].doClick();
                    }
                }
                if (r && !gagn) {
                    if (!click[upright] && numbers[upright] != 0
                            && !mines[upright]) {
                        click[upright] = true;
                        buttons[upright].doClick();
                    }
                }
            }
            if (d && !gagn) {
                if (!click[down] && !mines[down]) {
                    click[down] = true;
                    buttons[down].doClick();
                }
                if (l && !gagn) {
                    if (!click[downleft] && numbers[downleft] != 0
                            && !mines[downleft]) {
                        click[downleft] = true;
                        buttons[downleft].doClick();
                    }
                }
                if (r && !gagn) {
                    if (!click[downright]
                            && numbers[downright] != 0
                            && !mines[downright]) {
                        click[downright] = true;
                        buttons[downright].doClick();
                    }
                }
            }
            if (l && !gagn) {
                if (!click[left] && !mines[left]) {
                    click[left] = true;
                    buttons[left].doClick();
                }
            }
            if (r && !gagn) {
                if (!click[right] && !mines[right]) {
                    click[right] = true;
                    buttons[right].doClick();
                }
            }
        } else {
            buttons[cur].setText("" + numbers[cur]);
            if (!mines[cur] && numbers[cur] == 0) {
                buttons[cur].setText("");
            }
        }
        if (mines[cur] && !gagn) {
            //buttons[cur].setText("0");
            buttons[cur].setIcon(new ImageIcon(getClass().getResource("images/bombe.png")));
            doLose();
        }
    }
 
    public void checkWin() {
        for (int x = 0; x < ranges; x++) {
            for (int y = 0; y < colonnes; y++) {
                int cur = (ranges * y) + x;
                if (!click[cur]) {
                    if (mines[cur]) {
                        continue;
                    } else {
                        return;
                    }
                }
            }
        }
 
        doWin();
    }
   
 
    public void doWin() {
        if (!perdu && !gagn) {
            gagn = true;
            JOptionPane.showMessageDialog(null,
                    "Vous avez gagné!Nouveau jeu", "Vous avez perdu",
                    JOptionPane.INFORMATION_MESSAGE);
            newGameButton.doClick();
        }
    }
 
    public void doLose() {
        if (!perdu && !gagn) {
            perdu  = true;
            for (int i = 0; i < ranges * colonnes; i++) {
                if (!click[i]) {
                    buttons[i].doClick(0);
                }
            }

            validate();
            //repaint();
            JOptionPane.showMessageDialog(null,
                    "Vous avez perdu la partie!");
                    //JOptionPane.ERROR_MESSAGE);
                   // dispose();
                    
                    new JPanel();         
                   // setup();
        }
    }

    public boolean getFlag(){
        return this.flag;
    }

    public void setFlag(boolean f){
        this.flag = f;
    }







}
