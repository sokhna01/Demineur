import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;

public class Panel extends JPanel{

    
    public void paintComponent(Graphics g){
        g.setColor(new Color(0,0,0));
        g.fillRect(0, 0, getSize().width, getSize().height);
        for(int x = 0; x < Frame.y; x++){
            for(int y = 0; y < Frame.y; y++){
                if(Frame.cases[x][y] == 0){
                   // g.drawImage(, x, y, observer)
                }
            }
        }
        
    }

}
